//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by mfveutil.rc
//
#define IDD_VOLCOMP                     101
#define IDR_EDGEFINDER                  1001
#define IDC_FACTOR                      1001
#define IDR_HISTEQUAL                   1002
#define IDS_PROJNAME                    1003
#define IDR_NOISEREMOVAL                1004
#define IDR_MFVE                        1005
#define IDR_UNSHARPMASK                 1006
#define IDC_GAMMASLIDER                 1007
#define IDC_GAMMAEDIT                   1008
#define IDD_UNSHARPMASK                 1009
#define IDR_RESIZECROP                  1010
#define IDD_RESIZECROP                  1011
#define IDC_OUTPUTWIDTH                 1012
#define IDC_OUTPUTHEIGHT                1013
#define IDC_SOURCELEFT                  1014
#define IDC_SOURCETOP                   1015
#define IDC_SOURCEWIDTH                 1016
#define IDC_SOURCEHEIGHT                1017
#define IDR_VOLCOMP                     1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
