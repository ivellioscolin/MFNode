//----------------------------------------------------------------------------------------------
// MFNodeEnum.h
//----------------------------------------------------------------------------------------------
#ifndef MFNODEENUM_H
#define MFNODEENUM_H

enum MFNodeMediaEvent{
		
		ME_MFNodeSource                = 750,
		ME_MFNodeSource2               = 751,
		ME_MFNodeSourceStream          = 752,
		ME_MFNodeSourceStream2         = 753,
		ME_MFNodeStreamSink            = 754,
		ME_MFNodeByteStreamHandler     = 755,
		ME_MFNodeByteStreamHandler2    = 756,
		ME_MFNodeSampleRequest         = 757
};

#endif