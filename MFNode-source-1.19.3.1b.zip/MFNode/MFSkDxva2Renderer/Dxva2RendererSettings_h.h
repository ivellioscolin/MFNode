

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.00.0603 */
/* at Sat Jul 04 13:29:17 2015
 */
/* Compiler settings for Dxva2RendererSettings.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.00.0603 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __Dxva2RendererSettings_h_h__
#define __Dxva2RendererSettings_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IMFDxva2RendererSettings_FWD_DEFINED__
#define __IMFDxva2RendererSettings_FWD_DEFINED__
typedef interface IMFDxva2RendererSettings IMFDxva2RendererSettings;

#endif 	/* __IMFDxva2RendererSettings_FWD_DEFINED__ */


#ifndef __MFDxva2RendererSettings_FWD_DEFINED__
#define __MFDxva2RendererSettings_FWD_DEFINED__

#ifdef __cplusplus
typedef class MFDxva2RendererSettings MFDxva2RendererSettings;
#else
typedef struct MFDxva2RendererSettings MFDxva2RendererSettings;
#endif /* __cplusplus */

#endif 	/* __MFDxva2RendererSettings_FWD_DEFINED__ */


/* header files for imported files */
#include "unknwn.h"

#ifdef __cplusplus
extern "C"{
#endif 


/* interface __MIDL_itf_Dxva2RendererSettings_0000_0000 */
/* [local] */ 




extern RPC_IF_HANDLE __MIDL_itf_Dxva2RendererSettings_0000_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_Dxva2RendererSettings_0000_0000_v0_0_s_ifspec;

#ifndef __IMFDxva2RendererSettings_INTERFACE_DEFINED__
#define __IMFDxva2RendererSettings_INTERFACE_DEFINED__

/* interface IMFDxva2RendererSettings */
/* [unique][helpstring][uuid][object][local] */ 


EXTERN_C const IID IID_IMFDxva2RendererSettings;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F89DFD98-7E7A-43B2-BDD3-9071472CBB8B")
    IMFDxva2RendererSettings : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE SetBrightness( 
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0000,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0001) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetBrightness( 
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0002,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0003,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0004,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0005) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetContrast( 
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0006,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0007) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetContrast( 
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0008,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0009,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0010,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0011) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetHue( 
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0012,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0013) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetHue( 
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0014,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0015,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0016,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0017) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetSaturation( 
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0018,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0019) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSaturation( 
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0020,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0021,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0022,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0023) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetNoiseReduction( 
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0024,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0025) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetNoiseReduction( 
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0026,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0027,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0028,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0029) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetEdgeEnhancement( 
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0030,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0031) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetEdgeEnhancement( 
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0032,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0033,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0034,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0035) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetAnamorphicScaling( 
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0036,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0037) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetAnamorphicScaling( 
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0038,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0039,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0040,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0041) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IMFDxva2RendererSettingsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IMFDxva2RendererSettings * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IMFDxva2RendererSettings * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IMFDxva2RendererSettings * This);
        
        HRESULT ( STDMETHODCALLTYPE *SetBrightness )( 
            IMFDxva2RendererSettings * This,
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0000,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0001);
        
        HRESULT ( STDMETHODCALLTYPE *GetBrightness )( 
            IMFDxva2RendererSettings * This,
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0002,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0003,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0004,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0005);
        
        HRESULT ( STDMETHODCALLTYPE *SetContrast )( 
            IMFDxva2RendererSettings * This,
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0006,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0007);
        
        HRESULT ( STDMETHODCALLTYPE *GetContrast )( 
            IMFDxva2RendererSettings * This,
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0008,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0009,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0010,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0011);
        
        HRESULT ( STDMETHODCALLTYPE *SetHue )( 
            IMFDxva2RendererSettings * This,
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0012,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0013);
        
        HRESULT ( STDMETHODCALLTYPE *GetHue )( 
            IMFDxva2RendererSettings * This,
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0014,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0015,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0016,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0017);
        
        HRESULT ( STDMETHODCALLTYPE *SetSaturation )( 
            IMFDxva2RendererSettings * This,
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0018,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0019);
        
        HRESULT ( STDMETHODCALLTYPE *GetSaturation )( 
            IMFDxva2RendererSettings * This,
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0020,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0021,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0022,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0023);
        
        HRESULT ( STDMETHODCALLTYPE *SetNoiseReduction )( 
            IMFDxva2RendererSettings * This,
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0024,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0025);
        
        HRESULT ( STDMETHODCALLTYPE *GetNoiseReduction )( 
            IMFDxva2RendererSettings * This,
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0026,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0027,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0028,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0029);
        
        HRESULT ( STDMETHODCALLTYPE *SetEdgeEnhancement )( 
            IMFDxva2RendererSettings * This,
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0030,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0031);
        
        HRESULT ( STDMETHODCALLTYPE *GetEdgeEnhancement )( 
            IMFDxva2RendererSettings * This,
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0032,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0033,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0034,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0035);
        
        HRESULT ( STDMETHODCALLTYPE *SetAnamorphicScaling )( 
            IMFDxva2RendererSettings * This,
            /* [in] */ BOOL __MIDL__IMFDxva2RendererSettings0036,
            /* [in] */ INT __MIDL__IMFDxva2RendererSettings0037);
        
        HRESULT ( STDMETHODCALLTYPE *GetAnamorphicScaling )( 
            IMFDxva2RendererSettings * This,
            /* [out] */ BOOL *__MIDL__IMFDxva2RendererSettings0038,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0039,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0040,
            /* [out] */ INT *__MIDL__IMFDxva2RendererSettings0041);
        
        END_INTERFACE
    } IMFDxva2RendererSettingsVtbl;

    interface IMFDxva2RendererSettings
    {
        CONST_VTBL struct IMFDxva2RendererSettingsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMFDxva2RendererSettings_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IMFDxva2RendererSettings_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IMFDxva2RendererSettings_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IMFDxva2RendererSettings_SetBrightness(This,__MIDL__IMFDxva2RendererSettings0000,__MIDL__IMFDxva2RendererSettings0001)	\
    ( (This)->lpVtbl -> SetBrightness(This,__MIDL__IMFDxva2RendererSettings0000,__MIDL__IMFDxva2RendererSettings0001) ) 

#define IMFDxva2RendererSettings_GetBrightness(This,__MIDL__IMFDxva2RendererSettings0002,__MIDL__IMFDxva2RendererSettings0003,__MIDL__IMFDxva2RendererSettings0004,__MIDL__IMFDxva2RendererSettings0005)	\
    ( (This)->lpVtbl -> GetBrightness(This,__MIDL__IMFDxva2RendererSettings0002,__MIDL__IMFDxva2RendererSettings0003,__MIDL__IMFDxva2RendererSettings0004,__MIDL__IMFDxva2RendererSettings0005) ) 

#define IMFDxva2RendererSettings_SetContrast(This,__MIDL__IMFDxva2RendererSettings0006,__MIDL__IMFDxva2RendererSettings0007)	\
    ( (This)->lpVtbl -> SetContrast(This,__MIDL__IMFDxva2RendererSettings0006,__MIDL__IMFDxva2RendererSettings0007) ) 

#define IMFDxva2RendererSettings_GetContrast(This,__MIDL__IMFDxva2RendererSettings0008,__MIDL__IMFDxva2RendererSettings0009,__MIDL__IMFDxva2RendererSettings0010,__MIDL__IMFDxva2RendererSettings0011)	\
    ( (This)->lpVtbl -> GetContrast(This,__MIDL__IMFDxva2RendererSettings0008,__MIDL__IMFDxva2RendererSettings0009,__MIDL__IMFDxva2RendererSettings0010,__MIDL__IMFDxva2RendererSettings0011) ) 

#define IMFDxva2RendererSettings_SetHue(This,__MIDL__IMFDxva2RendererSettings0012,__MIDL__IMFDxva2RendererSettings0013)	\
    ( (This)->lpVtbl -> SetHue(This,__MIDL__IMFDxva2RendererSettings0012,__MIDL__IMFDxva2RendererSettings0013) ) 

#define IMFDxva2RendererSettings_GetHue(This,__MIDL__IMFDxva2RendererSettings0014,__MIDL__IMFDxva2RendererSettings0015,__MIDL__IMFDxva2RendererSettings0016,__MIDL__IMFDxva2RendererSettings0017)	\
    ( (This)->lpVtbl -> GetHue(This,__MIDL__IMFDxva2RendererSettings0014,__MIDL__IMFDxva2RendererSettings0015,__MIDL__IMFDxva2RendererSettings0016,__MIDL__IMFDxva2RendererSettings0017) ) 

#define IMFDxva2RendererSettings_SetSaturation(This,__MIDL__IMFDxva2RendererSettings0018,__MIDL__IMFDxva2RendererSettings0019)	\
    ( (This)->lpVtbl -> SetSaturation(This,__MIDL__IMFDxva2RendererSettings0018,__MIDL__IMFDxva2RendererSettings0019) ) 

#define IMFDxva2RendererSettings_GetSaturation(This,__MIDL__IMFDxva2RendererSettings0020,__MIDL__IMFDxva2RendererSettings0021,__MIDL__IMFDxva2RendererSettings0022,__MIDL__IMFDxva2RendererSettings0023)	\
    ( (This)->lpVtbl -> GetSaturation(This,__MIDL__IMFDxva2RendererSettings0020,__MIDL__IMFDxva2RendererSettings0021,__MIDL__IMFDxva2RendererSettings0022,__MIDL__IMFDxva2RendererSettings0023) ) 

#define IMFDxva2RendererSettings_SetNoiseReduction(This,__MIDL__IMFDxva2RendererSettings0024,__MIDL__IMFDxva2RendererSettings0025)	\
    ( (This)->lpVtbl -> SetNoiseReduction(This,__MIDL__IMFDxva2RendererSettings0024,__MIDL__IMFDxva2RendererSettings0025) ) 

#define IMFDxva2RendererSettings_GetNoiseReduction(This,__MIDL__IMFDxva2RendererSettings0026,__MIDL__IMFDxva2RendererSettings0027,__MIDL__IMFDxva2RendererSettings0028,__MIDL__IMFDxva2RendererSettings0029)	\
    ( (This)->lpVtbl -> GetNoiseReduction(This,__MIDL__IMFDxva2RendererSettings0026,__MIDL__IMFDxva2RendererSettings0027,__MIDL__IMFDxva2RendererSettings0028,__MIDL__IMFDxva2RendererSettings0029) ) 

#define IMFDxva2RendererSettings_SetEdgeEnhancement(This,__MIDL__IMFDxva2RendererSettings0030,__MIDL__IMFDxva2RendererSettings0031)	\
    ( (This)->lpVtbl -> SetEdgeEnhancement(This,__MIDL__IMFDxva2RendererSettings0030,__MIDL__IMFDxva2RendererSettings0031) ) 

#define IMFDxva2RendererSettings_GetEdgeEnhancement(This,__MIDL__IMFDxva2RendererSettings0032,__MIDL__IMFDxva2RendererSettings0033,__MIDL__IMFDxva2RendererSettings0034,__MIDL__IMFDxva2RendererSettings0035)	\
    ( (This)->lpVtbl -> GetEdgeEnhancement(This,__MIDL__IMFDxva2RendererSettings0032,__MIDL__IMFDxva2RendererSettings0033,__MIDL__IMFDxva2RendererSettings0034,__MIDL__IMFDxva2RendererSettings0035) ) 

#define IMFDxva2RendererSettings_SetAnamorphicScaling(This,__MIDL__IMFDxva2RendererSettings0036,__MIDL__IMFDxva2RendererSettings0037)	\
    ( (This)->lpVtbl -> SetAnamorphicScaling(This,__MIDL__IMFDxva2RendererSettings0036,__MIDL__IMFDxva2RendererSettings0037) ) 

#define IMFDxva2RendererSettings_GetAnamorphicScaling(This,__MIDL__IMFDxva2RendererSettings0038,__MIDL__IMFDxva2RendererSettings0039,__MIDL__IMFDxva2RendererSettings0040,__MIDL__IMFDxva2RendererSettings0041)	\
    ( (This)->lpVtbl -> GetAnamorphicScaling(This,__MIDL__IMFDxva2RendererSettings0038,__MIDL__IMFDxva2RendererSettings0039,__MIDL__IMFDxva2RendererSettings0040,__MIDL__IMFDxva2RendererSettings0041) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IMFDxva2RendererSettings_INTERFACE_DEFINED__ */



#ifndef __Dxva2RendererSettingsLib_LIBRARY_DEFINED__
#define __Dxva2RendererSettingsLib_LIBRARY_DEFINED__

/* library Dxva2RendererSettingsLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_Dxva2RendererSettingsLib;

EXTERN_C const CLSID CLSID_MFDxva2RendererSettings;

#ifdef __cplusplus

class DECLSPEC_UUID("1BA26999-60BF-46F5-84C6-8F2BA53617A1")
MFDxva2RendererSettings;
#endif
#endif /* __Dxva2RendererSettingsLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


