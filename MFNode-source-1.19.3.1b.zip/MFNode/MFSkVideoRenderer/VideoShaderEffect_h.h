

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.00.0603 */
/* at Sat Jul 04 13:29:15 2015
 */
/* Compiler settings for VideoShaderEffect.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.00.0603 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __VideoShaderEffect_h_h__
#define __VideoShaderEffect_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IMFVideoShaderEffect_FWD_DEFINED__
#define __IMFVideoShaderEffect_FWD_DEFINED__
typedef interface IMFVideoShaderEffect IMFVideoShaderEffect;

#endif 	/* __IMFVideoShaderEffect_FWD_DEFINED__ */


#ifndef __MFVideoShaderEffect_FWD_DEFINED__
#define __MFVideoShaderEffect_FWD_DEFINED__

#ifdef __cplusplus
typedef class MFVideoShaderEffect MFVideoShaderEffect;
#else
typedef struct MFVideoShaderEffect MFVideoShaderEffect;
#endif /* __cplusplus */

#endif 	/* __MFVideoShaderEffect_FWD_DEFINED__ */


/* header files for imported files */
#include "unknwn.h"

#ifdef __cplusplus
extern "C"{
#endif 


/* interface __MIDL_itf_VideoShaderEffect_0000_0000 */
/* [local] */ 




extern RPC_IF_HANDLE __MIDL_itf_VideoShaderEffect_0000_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_VideoShaderEffect_0000_0000_v0_0_s_ifspec;

#ifndef __IMFVideoShaderEffect_INTERFACE_DEFINED__
#define __IMFVideoShaderEffect_INTERFACE_DEFINED__

/* interface IMFVideoShaderEffect */
/* [unique][helpstring][uuid][object][local] */ 


EXTERN_C const IID IID_IMFVideoShaderEffect;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("95C8C8D2-14A8-4ED1-8064-9AB562F69E9B")
    IMFVideoShaderEffect : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE SetShaderReverseX( 
            /* [in] */ BOOL __MIDL__IMFVideoShaderEffect0000) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetShaderReverseY( 
            /* [in] */ BOOL __MIDL__IMFVideoShaderEffect0001) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetShaderNegatif( 
            /* [in] */ BOOL __MIDL__IMFVideoShaderEffect0002) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetShaderGray( 
            /* [in] */ BOOL __MIDL__IMFVideoShaderEffect0003) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetShaderGrayScale( 
            /* [in] */ BOOL __MIDL__IMFVideoShaderEffect0004) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetShaderColor( 
            /* [in] */ UINT __MIDL__IMFVideoShaderEffect0005) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetShaderContrast( 
            /* [in] */ FLOAT __MIDL__IMFVideoShaderEffect0006) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetShaderSaturation( 
            /* [in] */ FLOAT __MIDL__IMFVideoShaderEffect0007) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct IMFVideoShaderEffectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IMFVideoShaderEffect * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IMFVideoShaderEffect * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IMFVideoShaderEffect * This);
        
        HRESULT ( STDMETHODCALLTYPE *SetShaderReverseX )( 
            IMFVideoShaderEffect * This,
            /* [in] */ BOOL __MIDL__IMFVideoShaderEffect0000);
        
        HRESULT ( STDMETHODCALLTYPE *SetShaderReverseY )( 
            IMFVideoShaderEffect * This,
            /* [in] */ BOOL __MIDL__IMFVideoShaderEffect0001);
        
        HRESULT ( STDMETHODCALLTYPE *SetShaderNegatif )( 
            IMFVideoShaderEffect * This,
            /* [in] */ BOOL __MIDL__IMFVideoShaderEffect0002);
        
        HRESULT ( STDMETHODCALLTYPE *SetShaderGray )( 
            IMFVideoShaderEffect * This,
            /* [in] */ BOOL __MIDL__IMFVideoShaderEffect0003);
        
        HRESULT ( STDMETHODCALLTYPE *SetShaderGrayScale )( 
            IMFVideoShaderEffect * This,
            /* [in] */ BOOL __MIDL__IMFVideoShaderEffect0004);
        
        HRESULT ( STDMETHODCALLTYPE *SetShaderColor )( 
            IMFVideoShaderEffect * This,
            /* [in] */ UINT __MIDL__IMFVideoShaderEffect0005);
        
        HRESULT ( STDMETHODCALLTYPE *SetShaderContrast )( 
            IMFVideoShaderEffect * This,
            /* [in] */ FLOAT __MIDL__IMFVideoShaderEffect0006);
        
        HRESULT ( STDMETHODCALLTYPE *SetShaderSaturation )( 
            IMFVideoShaderEffect * This,
            /* [in] */ FLOAT __MIDL__IMFVideoShaderEffect0007);
        
        END_INTERFACE
    } IMFVideoShaderEffectVtbl;

    interface IMFVideoShaderEffect
    {
        CONST_VTBL struct IMFVideoShaderEffectVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMFVideoShaderEffect_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IMFVideoShaderEffect_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IMFVideoShaderEffect_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IMFVideoShaderEffect_SetShaderReverseX(This,__MIDL__IMFVideoShaderEffect0000)	\
    ( (This)->lpVtbl -> SetShaderReverseX(This,__MIDL__IMFVideoShaderEffect0000) ) 

#define IMFVideoShaderEffect_SetShaderReverseY(This,__MIDL__IMFVideoShaderEffect0001)	\
    ( (This)->lpVtbl -> SetShaderReverseY(This,__MIDL__IMFVideoShaderEffect0001) ) 

#define IMFVideoShaderEffect_SetShaderNegatif(This,__MIDL__IMFVideoShaderEffect0002)	\
    ( (This)->lpVtbl -> SetShaderNegatif(This,__MIDL__IMFVideoShaderEffect0002) ) 

#define IMFVideoShaderEffect_SetShaderGray(This,__MIDL__IMFVideoShaderEffect0003)	\
    ( (This)->lpVtbl -> SetShaderGray(This,__MIDL__IMFVideoShaderEffect0003) ) 

#define IMFVideoShaderEffect_SetShaderGrayScale(This,__MIDL__IMFVideoShaderEffect0004)	\
    ( (This)->lpVtbl -> SetShaderGrayScale(This,__MIDL__IMFVideoShaderEffect0004) ) 

#define IMFVideoShaderEffect_SetShaderColor(This,__MIDL__IMFVideoShaderEffect0005)	\
    ( (This)->lpVtbl -> SetShaderColor(This,__MIDL__IMFVideoShaderEffect0005) ) 

#define IMFVideoShaderEffect_SetShaderContrast(This,__MIDL__IMFVideoShaderEffect0006)	\
    ( (This)->lpVtbl -> SetShaderContrast(This,__MIDL__IMFVideoShaderEffect0006) ) 

#define IMFVideoShaderEffect_SetShaderSaturation(This,__MIDL__IMFVideoShaderEffect0007)	\
    ( (This)->lpVtbl -> SetShaderSaturation(This,__MIDL__IMFVideoShaderEffect0007) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IMFVideoShaderEffect_INTERFACE_DEFINED__ */



#ifndef __VideoShaderEffectLib_LIBRARY_DEFINED__
#define __VideoShaderEffectLib_LIBRARY_DEFINED__

/* library VideoShaderEffectLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_VideoShaderEffectLib;

EXTERN_C const CLSID CLSID_MFVideoShaderEffect;

#ifdef __cplusplus

class DECLSPEC_UUID("D3200A97-06F5-44A1-A4BC-9137E6A0748F")
MFVideoShaderEffect;
#endif
#endif /* __VideoShaderEffectLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


